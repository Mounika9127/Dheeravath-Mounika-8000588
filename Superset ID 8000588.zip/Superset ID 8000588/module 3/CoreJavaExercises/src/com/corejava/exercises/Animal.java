package com.corejava.exercises;

public class Animal {
    void makeSound() {
        System.out.println("Animal makes a sound");
    }
}
