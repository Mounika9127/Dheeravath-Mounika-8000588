package com.corejava.exercises;
import java.sql.*;
public class BasicJDBCConnection {
    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/college";
        String username = "root";
        String password = "mouni@mohan";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con =
                    DriverManager.getConnection(url, username, password);

            String query = "SELECT * FROM students";

            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery(query);

            while(rs.next()) {
                System.out.println(
                        rs.getInt("id") + " "
                                + rs.getString("name") + " "
                                + rs.getInt("age") + " "
                                + rs.getString("course")
                );
            }

            con.close();

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
