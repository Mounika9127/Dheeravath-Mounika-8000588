package com.corejava.exercises;

public class Piano implements Playable {

    @Override
    public void play() {
        System.out.println("Playing Piano");
    }
}
