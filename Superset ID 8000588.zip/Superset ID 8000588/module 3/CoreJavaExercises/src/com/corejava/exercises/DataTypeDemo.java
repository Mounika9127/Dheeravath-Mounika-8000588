package com.corejava.exercises;

public class DataTypeDemo {
    public static void main(String[] args){
        int num=100;
        float price=99.99f;
        double salary=50000.75;
        char grade='A';
        boolean status=true;
        System.out.println("Integer Value:"+num);
        System.out.println("Float Value:"+price);
        System.out.println("Double Value:"+salary);
        System.out.println("Character Value:"+grade);
        System.out.println("Boolean Value:"+status);
    }
}
