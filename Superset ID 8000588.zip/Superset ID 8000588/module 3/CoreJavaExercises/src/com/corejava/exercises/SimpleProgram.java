package com.corejava.exercises;

public class SimpleProgram {

    public static void main(String[] args) {
        System.out.println(
                "Hello Java");
    }
}
