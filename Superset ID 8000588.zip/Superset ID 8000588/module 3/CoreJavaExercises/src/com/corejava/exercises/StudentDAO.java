package com.corejava.exercises;
import java.sql.*;
public class StudentDAO {
    String url = "jdbc:mysql://localhost:3306/college";
    String username = "root";
    String password = "mouni@mohan";

    public void insertStudent(String name, int age, String course) {

        try {
            Connection con =
                    DriverManager.getConnection(url, username, password);

            String sql =
                    "INSERT INTO students(name, age, course) VALUES(?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setInt(2, age);
            ps.setString(3, course);

            int rows = ps.executeUpdate();

            System.out.println(rows + " row inserted");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateStudent(int id, String course) {

        try {

            Connection con =
                    DriverManager.getConnection(url, username, password);

            String sql =
                    "UPDATE students SET course=? WHERE id=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, course);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();

            System.out.println(rows + " row updated");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
