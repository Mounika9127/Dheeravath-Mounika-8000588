package com.corejava.exercises;
import java.util.Scanner;
public class Calculator {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter first number:");
        int num1=sc.nextInt();
        System.out.println("Enter second number:");
        int num2=sc.nextInt();
        System.out.println("Choose operation(+,-,*./:");
        char op=sc.next().charAt(0);
        int result=0;
        switch(op){
            case '+':
            result=num1+num2;
            break;
            case '-':
                result=num1-num2;
                break;
            case '*':
                result=num1*num2;
                break;
            case '/':
                if(num2!=0)
                    result=num1/num2;
                else{
                    System.out.println("Cannot divide by zero");
                    return;
                }
                break;
            default:
                System.out.println("Invalid operations");
                return;
        }
        System.out.println("Result="+result);
    }
}
