package com.corejava.exercises;
import java.sql.*;
public class TransactionRollbackDemo {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/college";
        String username = "root";
        String password = "mouni@mohan";

        Connection con = null;

        try {

            con = DriverManager.getConnection(url, username, password);

            con.setAutoCommit(false);

            String debitSql =
                    "UPDATE accounts SET balance = balance - ? WHERE account_id = ?";

            PreparedStatement debit =
                    con.prepareStatement(debitSql);

            debit.setDouble(1, 200);
            debit.setInt(2, 1);

            debit.executeUpdate();

            // Artificial Error
            int x = 10 / 0;

            String creditSql =
                    "UPDATE accounts SET balance = balance + ? WHERE account_id = ?";

            PreparedStatement credit =
                    con.prepareStatement(creditSql);

            credit.setDouble(1, 200);
            credit.setInt(2, 2);

            credit.executeUpdate();

            con.commit();

            System.out.println("Transaction Successful");

        } catch(Exception e) {

            try {
                if(con != null) {
                    con.rollback();
                    System.out.println("Transaction Failed");
                }
            } catch(Exception ex) {
                ex.printStackTrace();
            }

        } finally {

            try {
                if(con != null) {
                    con.close();
                }
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
    }
}
