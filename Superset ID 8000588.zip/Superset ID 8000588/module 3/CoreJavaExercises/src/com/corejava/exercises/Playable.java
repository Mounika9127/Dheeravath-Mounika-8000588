package com.corejava.exercises;

public interface Playable {
    void play();
}
