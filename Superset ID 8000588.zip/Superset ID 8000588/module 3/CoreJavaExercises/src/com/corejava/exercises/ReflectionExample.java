package com.corejava.exercises;

import java.lang.reflect.Method;

class TestClass {

    public void display() {
        System.out.println(
                "Method Invoked Successfully");
    }
}

public class ReflectionExample {

    public static void main(String[] args)
            throws Exception {

        Class<?> cls =
                Class.forName(
                        "com.corejava.exercises.TestClass");

        System.out.println(
                "Methods:");

        Method[] methods =
                cls.getDeclaredMethods();

        for (Method method : methods) {

            System.out.println(
                    method.getName());
        }

        Object obj =
                cls.getDeclaredConstructor()
                        .newInstance();

        Method m =
                cls.getDeclaredMethod(
                        "display");

        m.invoke(obj);
    }
}
