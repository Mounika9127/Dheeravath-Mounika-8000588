package com.corejava.exercises;

public class HelloWorld {
    public static void main(String[] args){
        System.out.println("Hello World!");
    }
}
