package com.corejava.exercises;
import java.sql.*;
public class TransactionDemo {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/college";
        String username = "root";
        String password = "mouni@mohan";

        try {

            Connection con =
                    DriverManager.getConnection(url, username, password);

            con.setAutoCommit(false);

            String debitSql =
                    "UPDATE accounts SET balance = balance - ? WHERE account_id = ?";

            PreparedStatement debit =
                    con.prepareStatement(debitSql);

            debit.setDouble(1, 200);
            debit.setInt(2, 1);

            debit.executeUpdate();

            String creditSql =
                    "UPDATE accounts SET balance = balance + ? WHERE account_id = ?";

            PreparedStatement credit =
                    con.prepareStatement(creditSql);

            credit.setDouble(1, 200);
            credit.setInt(2, 2);

            credit.executeUpdate();

            con.commit();

            System.out.println("Transaction Successful");

            con.close();

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
