package com.corejava.exercises;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class ExecutorCallableExample {

    public static void main(String[] args)
            throws Exception {

        ExecutorService executor =
                Executors.newFixedThreadPool(3);

        List<Callable<Integer>> tasks =
                new ArrayList<>();

        tasks.add(() -> 10 + 20);
        tasks.add(() -> 30 + 40);
        tasks.add(() -> 50 + 60);

        List<Future<Integer>> results =
                new ArrayList<>();

        for (Callable<Integer> task : tasks) {

            results.add(
                    executor.submit(task));
        }

        for (Future<Integer> result : results) {

            System.out.println(
                    "Result: "
                            + result.get());
        }

        executor.shutdown();
    }
}
