package com.corejava.exercises;

public class Main {
    public static void main(String[] args) {

        StudentDAO dao = new StudentDAO();

        dao.insertStudent("Kiran", 23, "DBMS");

        dao.updateStudent(1, "Advanced Java");
    }
}
