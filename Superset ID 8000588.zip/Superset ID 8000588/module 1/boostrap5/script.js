console.log("Bootstrap Project Loaded Successfully");

alert("Welcome to Bootstrap 5 Exercises");