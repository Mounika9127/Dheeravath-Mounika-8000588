console.log("Welcome to the Community Portal");

window.onload = function(){

    alert("Page Fully Loaded");

};

/* Event Data */

const events = [

    {
        name: "Music Concert",
        category: "Music",
        seats: 5,
        valid: true
    },

    {
        name: "Food Festival",
        category: "Food",
        seats: 10,
        valid: true
    },

    {
        name: "Old Event",
        category: "Music",
        seats: 0,
        valid: false
    }

];

/* Display Events */

const container =
document.querySelector("#eventContainer");

events.forEach(event => {

    if(event.valid && event.seats > 0){

        const card =
        document.createElement("div");

        card.classList.add("eventCard");

        card.innerHTML = `

            <h3>${event.name}</h3>

            <p>Category: ${event.category}</p>

            <p>Seats: ${event.seats}</p>

            <button onclick="registerEvent('${event.name}')">

                Register

            </button>

        `;

        container.appendChild(card);

    }

});

/* Register Function */

function registerEvent(name){

    try{

        const event =
        events.find(e => e.name === name);

        if(event.seats <= 0){

            throw "No Seats Available";

        }

        event.seats--;

        alert(`Registered for ${name}`);

        location.reload();

    }
    catch(error){

        console.log(error);

    }

}

/* Filter Events */

document
.getElementById("categoryFilter")
.onchange = function(){

    const category = this.value;

    console.log(category);

};

/* Search */

document
.getElementById("searchBox")
.addEventListener("keydown", function(){

    console.log("Searching...");

});

/* Functions */

function addEvent(name){

    console.log(`${name} Added`);

}

function registerUser(user){

    console.log(`${user} Registered`);

}

/* Closure */

function registrationCounter(){

    let total = 0;

    return function(){

        total++;

        console.log(total);

    };

}

const counter = registrationCounter();

counter();
counter();

/* Class */

class EventPortal{

    constructor(name, seats){

        this.name = name;
        this.seats = seats;

    }

}

EventPortal.prototype.checkAvailability =
function(){

    return this.seats > 0;

};

const event1 =
new EventPortal("Workshop", 20);

console.log(event1.checkAvailability());

console.log(Object.entries(event1));

/* Arrays */

const eventList = [];

eventList.push("Music Concert");

eventList.push("Food Festival");

const music =
eventList.filter(event =>
event.includes("Music"));

console.log(music);

const cards =
eventList.map(event =>
`Workshop on ${event}`);

console.log(cards);

/* Fetch API */

fetch("https://jsonplaceholder.typicode.com/posts")

.then(response => response.json())

.then(data => console.log(data))

.catch(error => console.log(error));

/* Async Await */

async function loadEvents(){

    try{

        const response =
        await fetch(
        "https://jsonplaceholder.typicode.com/posts"
        );

        const data =
        await response.json();

        console.log(data);

    }
    catch(error){

        console.log(error);

    }

}

loadEvents();

/* Form */

document
.getElementById("registerForm")

.addEventListener("submit",
function(event){

    event.preventDefault();

    const form = event.target;

    const name =
    form.elements["username"].value;

    const email =
    form.elements["email"].value;

    if(name === "" || email === ""){

        document
        .getElementById("error")
        .innerText =
        "All Fields Required";

        return;

    }

    console.log(name);
    console.log(email);

});

/* AJAX POST */

const userData = {

    name: "Mounika",

    email: "test@gmail.com"

};

setTimeout(() => {

    fetch(
        "https://jsonplaceholder.typicode.com/posts",

        {

            method: "POST",

            headers: {

                "Content-Type":
                "application/json"

            },

            body: JSON.stringify(userData)

        }

    )

    .then(response => response.json())

    .then(data => {

        console.log("Success");

        console.log(data);

    })

    .catch(error => {

        console.log("Failed");

    });

}, 2000);

/* jQuery */

$("#registerBtn").click(function(){

    $(".eventCard").fadeOut();

    $(".eventCard").fadeIn();

});