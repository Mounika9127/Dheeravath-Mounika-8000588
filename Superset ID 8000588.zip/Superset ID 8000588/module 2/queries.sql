mysql> show tables;
+------------------------+
| Tables_in_event_portal |
+------------------------+
| events                 |
| feedback               |
| registrations          |
| resources              |
| sessions               |
| users                  |
+------------------------+
6 rows in set (0.02 sec)

mysql> INSERT INTO Users VALUES
    -> (1,'Alice Johnson','alice@example.com','New York','2024-12-01'),
    -> (2,'Bob Smith','bob@example.com','Los Angeles','2024-12-05'),
    -> (3,'Charlie Lee','charlie@example.com','Chicago','2024-12-10'),
    -> (4,'Diana King','diana@example.com','New York','2025-01-15'),
    -> (5,'Ethan Hunt','ethan@example.com','Los Angeles','2025-02-01');
Query OK, 5 rows affected (0.02 sec)
Records: 5  Duplicates: 0  Warnings: 0

mysql> select * from users;
+---------+---------------+---------------------+-------------+-------------------+
| user_id | full_name     | email               | city        | registration_date |
+---------+---------------+---------------------+-------------+-------------------+
|       1 | Alice Johnson | alice@example.com   | New York    | 2024-12-01        |
|       2 | Bob Smith     | bob@example.com     | Los Angeles | 2024-12-05        |
|       3 | Charlie Lee   | charlie@example.com | Chicago     | 2024-12-10        |
|       4 | Diana King    | diana@example.com   | New York    | 2025-01-15        |
|       5 | Ethan Hunt    | ethan@example.com   | Los Angeles | 2025-02-01        |
+---------+---------------+---------------------+-------------+-------------------+
5 rows in set (0.01 sec)

mysql> INSERT INTO Events VALUES
    -> (1,'Tech Innovators Meetup',
    -> 'A meetup for tech enthusiasts.',
    -> 'New York',
    -> '2025-06-10 10:00:00',
    -> '2025-06-10 16:00:00',
    -> 'upcoming',
    -> 1),
    ->
    -> (2,'AI & ML Conference',
    -> 'Conference on AI and ML advancements.',
    -> 'Chicago',
    -> '2025-05-15 09:00:00',
    -> '2025-05-15 17:00:00',
    -> 'completed',
    -> 3),
    ->
    -> (3,'Frontend Development Bootcamp',
    -> 'Hands-on training on frontend tech.',
    -> 'Los Angeles',
    -> '2025-07-01 10:00:00',
    -> '2025-07-03 16:00:00',
    -> 'upcoming',
    -> 2);
Query OK, 3 rows affected (0.04 sec)
Records: 3  Duplicates: 0  Warnings: 0

mysql> 2)select * from events;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '2)select * from events' at line 1
mysql> select * from Events;
+----------+-------------------------------+---------------------------------------+-------------+---------------------+---------------------+-----------+--------------+
| event_id | title                         | description                           | city        | start_date          | end_date            | status    | organizer_id |
+----------+-------------------------------+---------------------------------------+-------------+---------------------+---------------------+-----------+--------------+
|        1 | Tech Innovators Meetup        | A meetup for tech enthusiasts.        | New York    | 2025-06-10 10:00:00 | 2025-06-10 16:00:00 | upcoming  |            1 |
|        2 | AI & ML Conference            | Conference on AI and ML advancements. | Chicago     | 2025-05-15 09:00:00 | 2025-05-15 17:00:00 | completed |            3 |
|        3 | Frontend Development Bootcamp | Hands-on training on frontend tech.   | Los Angeles | 2025-07-01 10:00:00 | 2025-07-03 16:00:00 | upcoming  |            2 |
+----------+-------------------------------+---------------------------------------+-------------+---------------------+---------------------+-----------+--------------+
3 rows in set (0.00 sec)

mysql> INSERT INTO Sessions VALUES
    -> (1,1,'Opening Keynote','Dr. Tech',
    -> '2025-06-10 10:00:00',
    -> '2025-06-10 11:00:00'),
    ->
    -> (2,1,'Future of Web Dev','Alice Johnson',
    -> '2025-06-10 11:15:00',
    -> '2025-06-10 12:30:00'),
    ->
    -> (3,2,'AI in Healthcare','Charlie Lee',
    -> '2025-05-15 09:30:00',
    -> '2025-05-15 11:00:00'),
    ->
    -> (4,3,'Intro to HTML5','Bob Smith',
    -> '2025-07-01 10:00:00',
    -> '2025-07-01 12:00:00');
Query OK, 4 rows affected (0.03 sec)
Records: 4  Duplicates: 0  Warnings: 0

mysql> select * from Sessions;
+------------+----------+-------------------+---------------+---------------------+---------------------+
| session_id | event_id | title             | speaker_name  | start_time          | end_time            |
+------------+----------+-------------------+---------------+---------------------+---------------------+
|          1 |        1 | Opening Keynote   | Dr. Tech      | 2025-06-10 10:00:00 | 2025-06-10 11:00:00 |
|          2 |        1 | Future of Web Dev | Alice Johnson | 2025-06-10 11:15:00 | 2025-06-10 12:30:00 |
|          3 |        2 | AI in Healthcare  | Charlie Lee   | 2025-05-15 09:30:00 | 2025-05-15 11:00:00 |
|          4 |        3 | Intro to HTML5    | Bob Smith     | 2025-07-01 10:00:00 | 2025-07-01 12:00:00 |
+------------+----------+-------------------+---------------+---------------------+---------------------+
4 rows in set (0.00 sec)

mysql> INSERT INTO Registrations VALUES
    -> (1,1,1,'2025-05-01'),
    -> (2,2,1,'2025-05-02'),
    -> (3,3,2,'2025-04-30'),
    -> (4,4,2,'2025-04-28'),
    -> (5,5,3,'2025-06-15');
Query OK, 5 rows affected (0.02 sec)
Records: 5  Duplicates: 0  Warnings: 0

mysql> select * from Registrations;
+-----------------+---------+----------+-------------------+
| registration_id | user_id | event_id | registration_date |
+-----------------+---------+----------+-------------------+
|               1 |       1 |        1 | 2025-05-01        |
|               2 |       2 |        1 | 2025-05-02        |
|               3 |       3 |        2 | 2025-04-30        |
|               4 |       4 |        2 | 2025-04-28        |
|               5 |       5 |        3 | 2025-06-15        |
+-----------------+---------+----------+-------------------+
5 rows in set (0.00 sec)

mysql> INSERT INTO Feedback VALUES
    -> (1,3,2,4,'Great insights!','2025-05-16'),
    -> (2,4,2,5,'Very informative.','2025-05-16'),
    -> (3,2,1,3,'Could be better.','2025-06-11');
Query OK, 3 rows affected (0.01 sec)
Records: 3  Duplicates: 0  Warnings: 0

mysql> select * from Feedback;
+-------------+---------+----------+--------+-------------------+---------------+
| feedback_id | user_id | event_id | rating | comments          | feedback_date |
+-------------+---------+----------+--------+-------------------+---------------+
|           1 |       3 |        2 |      4 | Great insights!   | 2025-05-16    |
|           2 |       4 |        2 |      5 | Very informative. | 2025-05-16    |
|           3 |       2 |        1 |      3 | Could be better.  | 2025-06-11    |
+-------------+---------+----------+--------+-------------------+---------------+
3 rows in set (0.00 sec)

mysql> INSERT INTO Resources VALUES
    -> (1,1,'pdf',
    -> 'https://portal.com/resources/tech_meetup_agenda.pdf',
    -> '2025-05-01 10:00:00'),
    ->
    -> (2,2,'image',
    -> 'https://portal.com/resources/ai_poster.jpg',
    -> '2025-04-20 09:00:00'),
    ->
    -> (3,3,'link',
    -> 'https://portal.com/resources/html5_docs',
    -> '2025-06-25 15:00:00');
Query OK, 3 rows affected (0.01 sec)
Records: 3  Duplicates: 0  Warnings: 0

mysql> select * from Resources;
+-------------+----------+---------------+-----------------------------------------------------+---------------------+
| resource_id | event_id | resource_type | resource_url                                        | uploaded_at         |
+-------------+----------+---------------+-----------------------------------------------------+---------------------+
|           1 |        1 | pdf           | https://portal.com/resources/tech_meetup_agenda.pdf | 2025-05-01 10:00:00 |
|           2 |        2 | image         | https://portal.com/resources/ai_poster.jpg          | 2025-04-20 09:00:00 |
|           3 |        3 | link          | https://portal.com/resources/html5_docs             | 2025-06-25 15:00:00 |
+-------------+----------+---------------+-----------------------------------------------------+---------------------+
3 rows in set (0.01 sec)
exercise1
mysql> SELECT *
    -> FROM Users u
    -> JOIN Registrations r
    ->     ON u.user_id = r.user_id
    -> JOIN Events e
    ->     ON r.event_id = e.event_id
    -> WHERE e.status = 'upcoming'
    ->   AND u.city = e.city
    -> ORDER BY e.start_date;
+---------+---------------+-------------------+-------------+-------------------+-----------------+---------+----------+-------------------+----------+-------------------------------+-------------------------------------+-------------+---------------------+---------------------+----------+--------------+
| user_id | full_name     | email             | city        | registration_date | registration_id | user_id | event_id | registration_date | event_id | title                         | description                         | city        | start_date          | end_date            | status   | organizer_id |
+---------+---------------+-------------------+-------------+-------------------+-----------------+---------+----------+-------------------+----------+-------------------------------+-------------------------------------+-------------+---------------------+---------------------+----------+--------------+
|       1 | Alice Johnson | alice@example.com | New York    | 2024-12-01        |               1 |       1 |        1 | 2025-05-01        |        1 | Tech Innovators Meetup        | A meetup for tech enthusiasts.      | New York    | 2025-06-10 10:00:00 | 2025-06-10 16:00:00 | upcoming |            1 |
|       5 | Ethan Hunt    | ethan@example.com | Los Angeles | 2025-02-01        |               5 |       5 |        3 | 2025-06-15        |        3 | Frontend Development Bootcamp | Hands-on training on frontend tech. | Los Angeles | 2025-07-01 10:00:00 | 2025-07-03 16:00:00 | upcoming |            2 |
+---------+---------------+-------------------+-------------+-------------------+-----------------+---------+----------+-------------------+----------+-------------------------------+-------------------------------------+-------------+---------------------+---------------------+----------+--------------+
2 rows in set (0.01 sec)
mysql> SELECT
    ->     u.full_name,
    ->     e.title,
    ->     e.city,
    ->     e.start_date
    -> FROM Users u
    -> JOIN Registrations r
    ->     ON u.user_id = r.user_id
    -> JOIN Events e
    ->     ON r.event_id = e.event_id
    -> WHERE e.status = 'upcoming'
    ->   AND u.city = e.city
    -> ORDER BY e.start_date;
+---------------+-------------------------------+-------------+---------------------+
| full_name     | title                         | city        | start_date          |
+---------------+-------------------------------+-------------+---------------------+
| Alice Johnson | Tech Innovators Meetup        | New York    | 2025-06-10 10:00:00 |
| Ethan Hunt    | Frontend Development Bootcamp | Los Angeles | 2025-07-01 10:00:00 |
+---------------+-------------------------------+-------------+---------------------+
2 rows in set (0.04 sec)
exercise2
mysql> SELECT
    ->     e.event_id,
    ->     e.title,
    ->     AVG(f.rating) AS avg_rating,
    ->     COUNT(*) AS feedback_count
    -> FROM Events e
    -> JOIN Feedback f
    ->     ON e.event_id = f.event_id
    -> GROUP BY e.event_id, e.title
    -> HAVING COUNT(*) >= 10
    -> ORDER BY avg_rating DESC;
Empty set (0.07 sec)
exercise3
mysql> SELECT u.user_id, u.full_name
    -> FROM Users u
    -> WHERE NOT EXISTS (
    ->     SELECT 1
    ->     FROM Registrations r
    ->     WHERE r.user_id = u.user_id
    ->       AND r.registration_date >= CURDATE() - INTERVAL 90 DAY
    -> );
+---------+---------------+
| user_id | full_name     |
+---------+---------------+
|       1 | Alice Johnson |
|       2 | Bob Smith     |
|       3 | Charlie Lee   |
|       4 | Diana King    |
|       5 | Ethan Hunt    |
+---------+---------------+
5 rows in set (0.04 sec)
exercise4
mysql>
mysql> SELECT
    ->     event_id,
    ->     COUNT(*) AS session_count
    -> FROM Sessions
    -> WHERE TIME(start_time) BETWEEN '10:00:00' AND '12:00:00'
    -> GROUP BY event_id;
+----------+---------------+
| event_id | session_count |
+----------+---------------+
|        1 |             2 |
|        3 |             1 |
+----------+---------------+
2 rows in set (0.01 sec)
exercise5
mysql> SELECT
    ->     u.city,
    ->     COUNT(DISTINCT u.user_id) AS active_users
    -> FROM Users u
    -> JOIN Registrations r
    ->     ON u.user_id = r.user_id
    -> GROUP BY u.city
    -> ORDER BY active_users DESC
    -> LIMIT 5;
+-------------+--------------+
| city        | active_users |
+-------------+--------------+
| Los Angeles |            2 |
| New York    |            2 |
| Chicago     |            1 |
+-------------+--------------+
3 rows in set (0.02 sec)
exercise6
mysql> SELECT
    ->     e.event_id,
    ->     e.title,
    ->     COUNT(r.resource_id) AS total_resources
    -> FROM Events e
    -> LEFT JOIN Resources r
    ->     ON e.event_id = r.event_id
    -> GROUP BY e.event_id, e.title;
+----------+-------------------------------+-----------------+
| event_id | title                         | total_resources |
+----------+-------------------------------+-----------------+
|        1 | Tech Innovators Meetup        |               1 |
|        2 | AI & ML Conference            |               1 |
|        3 | Frontend Development Bootcamp |               1 |
+----------+-------------------------------+-----------------+
3 rows in set (0.01 sec)
exercise7
mysql> SELECT
    ->     u.user_id,
    ->     u.full_name,
    ->     e.title AS event_name,
    ->     f.rating,
    ->     f.comments
    -> FROM Feedback f
    -> JOIN Users u
    ->     ON f.user_id = u.user_id
    -> JOIN Events e
    ->     ON f.event_id = e.event_id
    -> WHERE f.rating < 3;
Empty set (0.00 sec)
exercise8
mysql> SELECT
    ->     e.event_id,
    ->     e.title,
    ->     COUNT(s.session_id) AS session_count
    -> FROM Events e
    -> LEFT JOIN Sessions s
    ->     ON e.event_id = s.event_id
    -> WHERE e.status = 'upcoming'
    -> GROUP BY e.event_id, e.title;
+----------+-------------------------------+---------------+
| event_id | title                         | session_count |
+----------+-------------------------------+---------------+
|        1 | Tech Innovators Meetup        |             2 |
|        3 | Frontend Development Bootcamp |             1 |
+----------+-------------------------------+---------------+
2 rows in set (0.00 sec)
exercise9
mysql> SELECT
    ->     u.user_id AS organizer_id,
    ->     u.full_name,
    ->     COUNT(e.event_id) AS total_events
    -> FROM users u
    -> JOIN events e
    ->     ON u.user_id = e.organizer_id
    -> GROUP BY u.user_id, u.full_name;
+--------------+---------------+--------------+
| organizer_id | full_name     | total_events |
+--------------+---------------+--------------+
|            1 | Alice Johnson |            1 |
|            2 | Bob Smith     |            1 |
|            3 | Charlie Lee   |            1 |
+--------------+---------------+--------------+
3 rows in set (0.01 sec)
exercise10
mysql> SELECT DISTINCT e.event_id, e.title
    -> FROM events e
    -> WHERE EXISTS (
    ->     SELECT 1
    ->     FROM registrations r
    ->     WHERE r.event_id = e.event_id
    -> )
    -> AND NOT EXISTS (
    ->     SELECT 1
    ->     FROM feedback f
    ->     WHERE f.event_id = e.event_id
    -> );
+----------+-------------------------------+
| event_id | title                         |
+----------+-------------------------------+
|        3 | Frontend Development Bootcamp |
+----------+-------------------------------+
1 row in set (0.01 sec)
exercise11
mysql> SELECT
    ->     DATE(r.registration_date) AS reg_date,
    ->     COUNT(DISTINCT r.user_id) AS new_users
    -> FROM registrations r
    -> WHERE r.registration_date >= CURDATE() - INTERVAL 7 DAY
    -> GROUP BY DATE(r.registration_date)
    -> ORDER BY reg_date;
Empty set (0.01 sec)
exercise12
mysql> SELECT
    ->     e.event_id,
    ->     e.title,
    ->     COUNT(s.session_id) AS session_count
    -> FROM events e
    -> JOIN sessions s
    ->     ON e.event_id = s.event_id
    -> GROUP BY e.event_id, e.title
    -> HAVING COUNT(s.session_id) = (
    ->     SELECT MAX(session_count)
    ->     FROM (
    ->         SELECT COUNT(*) AS session_count
    ->         FROM sessions
    ->         GROUP BY event_id
    ->     ) AS sub
    -> );
+----------+------------------------+---------------+
| event_id | title                  | session_count |
+----------+------------------------+---------------+
|        1 | Tech Innovators Meetup |             2 |
+----------+------------------------+---------------+
1 row in set (0.06 sec)
exercise13
mysql> SELECT
    ->     e.city,
    ->     AVG(f.rating) AS avg_rating
    -> FROM events e
    -> JOIN feedback f
    ->     ON e.event_id = f.event_id
    -> GROUP BY e.city;
+----------+------------+
| city     | avg_rating |
+----------+------------+
| New York |     3.0000 |
| Chicago  |     4.5000 |
+----------+------------+
2 rows in set (0.00 sec)
exercise14
mysql> SELECT
    ->     e.event_id,
    ->     e.title,
    ->     COUNT(r.user_id) AS total_registrations
    -> FROM events e
    -> JOIN registrations r
    ->     ON e.event_id = r.event_id
    -> GROUP BY e.event_id, e.title
    -> ORDER BY total_registrations DESC
    -> LIMIT 3;
+----------+-------------------------------+---------------------+
| event_id | title                         | total_registrations |
+----------+-------------------------------+---------------------+
|        1 | Tech Innovators Meetup        |                   2 |
|        2 | AI & ML Conference            |                   2 |
|        3 | Frontend Development Bootcamp |                   1 |
+----------+-------------------------------+---------------------+
3 rows in set (0.00 sec)
exercise15
mysql> SELECT
    ->     s1.event_id,
    ->     s1.session_id AS session1,
    ->     s2.session_id AS session2,
    ->     s1.start_time AS s1_start,
    ->     s1.end_time AS s1_end,
    ->     s2.start_time AS s2_start,
    ->     s2.end_time AS s2_end
    -> FROM Sessions s1
    -> JOIN Sessions s2
    ->     ON s1.event_id = s2.event_id
    ->     AND s1.session_id < s2.session_id
    -> WHERE s1.start_time < s2.end_time
    ->   AND s2.start_time < s1.end_time;
Empty set (0.03 sec)
mysql> INSERT INTO Users (full_name, email, city, registration_date)
    -> VALUES ('Test User', 'test@example.com', 'Hyderabad', CURDATE());
Query OK, 1 row affected (0.10 sec)
exercise16
mysql> SELECT u.user_id, u.full_name
    -> FROM users u
    -> WHERE u.registration_date >= CURDATE() - INTERVAL 30 DAY
    -> AND NOT EXISTS (
    ->     SELECT 1
    ->     FROM registrations r
    ->     WHERE r.user_id = u.user_id
    -> );
+---------+-----------+
| user_id | full_name |
+---------+-----------+
|       6 | Test User |
+---------+-----------+
1 row in set (0.01 sec)
exercise17
mysql> SELECT
    ->     event_id,
    ->     COUNT(session_id) AS total_sessions
    -> FROM sessions
    -> GROUP BY event_id
    -> HAVING COUNT(session_id) > 1;
+----------+----------------+
| event_id | total_sessions |
+----------+----------------+
|        1 |              2 |
+----------+----------------+
1 row in set (0.00 sec)
exercise18
mysql> SELECT
    ->     e.event_id,
    ->     e.title,
    ->     COUNT(s.session_id) AS total_sessions
    -> FROM events e
    -> JOIN sessions s
    ->     ON e.event_id = s.event_id
    -> GROUP BY e.event_id, e.title
    -> HAVING COUNT(s.session_id) > 1;
+----------+------------------------+----------------+
| event_id | title                  | total_sessions |
+----------+------------------------+----------------+
|        1 | Tech Innovators Meetup |              2 |
+----------+------------------------+----------------+
1 row in set (0.00 sec)
exercise19
mysql> SELECT e.event_id, e.title
    -> FROM events e
    -> LEFT JOIN resources r
    ->     ON e.event_id = r.event_id
    -> WHERE r.event_id IS NULL;
Empty set (0.00 sec)
exercise20
mysql> SELECT
    ->     e.event_id,
    ->     e.title,
    ->     COUNT(DISTINCT r.user_id) AS total_registrations,
    ->     AVG(f.rating) AS avg_rating
    -> FROM events e
    -> LEFT JOIN registrations r
    ->     ON e.event_id = r.event_id
    -> LEFT JOIN feedback f
    ->     ON e.event_id = f.event_id
    -> WHERE e.status = 'completed'
    -> GROUP BY e.event_id, e.title;
+----------+--------------------+---------------------+------------+
| event_id | title              | total_registrations | avg_rating |
+----------+--------------------+---------------------+------------+
|        2 | AI & ML Conference |                   2 |     4.5000 |
+----------+--------------------+---------------------+------------+
1 row in set (0.00 sec)
exercise21
mysql> SELECT
    ->     u.user_id,
    ->     u.full_name,
    ->     COUNT(DISTINCT r.event_id) AS events_attended,
    ->     COUNT(f.feedback_id) AS feedback_given
    -> FROM users u
    -> LEFT JOIN registrations r
    ->     ON u.user_id = r.user_id
    -> LEFT JOIN feedback f
    ->     ON u.user_id = f.user_id
    -> GROUP BY u.user_id, u.full_name;
+---------+---------------+-----------------+----------------+
| user_id | full_name     | events_attended | feedback_given |
+---------+---------------+-----------------+----------------+
|       1 | Alice Johnson |               1 |              0 |
|       2 | Bob Smith     |               1 |              1 |
|       3 | Charlie Lee   |               1 |              1 |
|       4 | Diana King    |               1 |              1 |
|       5 | Ethan Hunt    |               1 |              0 |
|       6 | Test User     |               0 |              0 |
+---------+---------------+-----------------+----------------+
6 rows in set (0.00 sec)
exercise22
mysql>
mysql> SELECT
    ->     u.user_id,
    ->     u.full_name,
    ->     COUNT(f.feedback_id) AS total_feedback
    -> FROM users u
    -> JOIN feedback f
    ->     ON u.user_id = f.user_id
    -> GROUP BY u.user_id, u.full_name
    -> ORDER BY total_feedback DESC
    -> LIMIT 5;
+---------+-------------+----------------+
| user_id | full_name   | total_feedback |
+---------+-------------+----------------+
|       2 | Bob Smith   |              1 |
|       3 | Charlie Lee |              1 |
|       4 | Diana King  |              1 |
+---------+-------------+----------------+
3 rows in set (0.00 sec)
exercise23
mysql> SELECT
    ->     user_id,
    ->     event_id,
    ->     COUNT(*) AS total_registrations
    -> FROM Registrations
    -> GROUP BY user_id, event_id
    -> HAVING COUNT(*) > 1;
Empty set (0.00 sec)
exercise24
mysql> SELECT
    ->     DATE_FORMAT(registration_date, '%Y-%m') AS month,
    ->     COUNT(*) AS total_registrations
    -> FROM registrations
    -> WHERE registration_date >= CURDATE() - INTERVAL 12 MONTH
    -> GROUP BY DATE_FORMAT(registration_date, '%Y-%m')
    -> ORDER BY month;
+---------+---------------------+
| month   | total_registrations |
+---------+---------------------+
| 2025-06 |                   1 |
+---------+---------------------+
1 row in set (0.02 sec)
exercise25
mysql> SELECT
    ->     event_id,
    ->     AVG(TIMESTAMPDIFF(MINUTE, start_time, end_time)) AS avg_duration_minutes
    -> FROM sessions
    -> GROUP BY event_id;
+----------+----------------------+
| event_id | avg_duration_minutes |
+----------+----------------------+
|        1 |              67.5000 |
|        2 |              90.0000 |
|        3 |             120.0000 |
+----------+----------------------+
3 rows in set (0.00 sec)

mysql> SELECT e.event_id, e.title
    -> FROM events e
    -> LEFT JOIN sessions s
    ->     ON e.event_id = s.event_id
    -> WHERE s.session_id IS NULL;
Empty set (0.00 sec)

